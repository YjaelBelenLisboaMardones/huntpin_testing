package com.microservice.atencion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceAtencionApplicationTests {

	@Test
	void contextLoads() {
	}

}
