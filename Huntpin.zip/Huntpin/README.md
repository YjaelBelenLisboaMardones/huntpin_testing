REQUEST POSTMAN

GET : http://127.0.0.1:8090/api/producto/listar
GET PRODUCTO : http://127.0.0.1:8090/api/producto/{id_producto}
POST : http://127.0.0.1:8090/api/producto
PUT : http://127.0.0.1:8090/api/producto/{id_producto}
DELETE : http://127.0.0.1:8090/api/producto/{id}
