package com.microservice.producto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceProductoApplicationTests {

	@Test
	void contextLoads() {
	}

}
